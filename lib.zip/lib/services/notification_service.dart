import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:bigbreakingwire/services/api_service.dart';
import 'package:bigbreakingwire/models/article_model.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  Timer? _articlePollingTimer; // Timer for article notifications
  Timer? _generalNotificationTimer; // Timer for general notifications
  DateTime? _lastFetchedPostTime; // Store the last fetched article's post time
  final ApiService _apiService = ApiService();

  // Initialize the notification plugin with proper channel setup
  Future<void> initialize() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        final payload = response.payload;
        if (payload != null) {
          // Handle notification tap and navigate to specific article
          print('Notification clicked with payload: $payload');
          // Navigate to the article screen
          // You can use a navigator key or any other method to navigate
        }
      },
    );

    // Create notification channels for each category
    await _createNotificationChannels();
  }

  Future<void> _createNotificationChannels() async {
    final categories = _apiService.getCategories().keys;

    for (var category in categories) {
      final channel = AndroidNotificationChannel(
        category, // id
        category, // name
        description: 'Channel for $category notifications',
        importance: Importance.max,
      );

      await _flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);
    }

    // Create a notification channel for Block Deals
    final blockDealsChannel = AndroidNotificationChannel(
      'BlockDeals', // id
      'Block Deals', // name
      description: 'Channel for Block Deals notifications',
      importance: Importance.max,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(blockDealsChannel);
  }

  // Helper to download network image and store it locally as File for notification
  Future<String?> _downloadAndSaveImage(
      String imageUrl, String fileName) async {
    try {
      final Directory directory = await getApplicationDocumentsDirectory();
      final String filePath = '${directory.path}/$fileName';
      final http.Response response = await http.get(Uri.parse(imageUrl));

      final File file = File(filePath);
      await file.writeAsBytes(response.bodyBytes);

      return filePath; // Return the local file path
    } catch (e) {
      print('Error downloading image: $e');
      return null;
    }
  }

  // Send a notification with article details, and use the correct channel ID and name
  Future<void> sendNotification(String title, String body, String payload,
      String? imageUrl, String channelId) async {
    String? bigPicturePath;

    if (imageUrl != null && imageUrl.isNotEmpty) {
      bigPicturePath = await _downloadAndSaveImage(imageUrl, 'big_picture.jpg');
    }

    final BigPictureStyleInformation bigPictureStyleInformation =
        BigPictureStyleInformation(
      bigPicturePath != null
          ? FilePathAndroidBitmap(bigPicturePath)
          : const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      largeIcon: const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      contentTitle: title,
      summaryText: body,
      htmlFormatContentTitle: true,
      htmlFormatSummaryText: true,
    );

    final AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      channelId, // Set the correct channel ID
      channelId, // Set the correct channel name
      channelDescription: 'Channel for $channelId notifications',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: true,
      color: const Color(0xFFBA2026),
      styleInformation: bigPictureStyleInformation,
      ticker: '$channelId Notification',
    );

    NotificationDetails generalNotificationDetails =
        NotificationDetails(android: androidDetails);

    await _flutterLocalNotificationsPlugin.show(
      0, // Notification ID
      title, // Notification title
      body, // Notification body
      generalNotificationDetails,
      payload: payload, // Payload for deep linking or navigation
    );
  }

  // Fetch articles and send notification if a new post is detected
  Future<void> checkForNewArticlesAndSendNotification() async {
    try {
      final categories = _apiService.getCategories().keys;

      Article? latestArticle;
      Article? latestBlockDealsArticle;

      for (var category in categories) {
        final articles = await _apiService.fetchArticlesByCategory(category, 1);

        if (articles.isNotEmpty) {
          final article = articles.first;

          if (latestArticle == null ||
              article.postDate.isAfter(latestArticle.postDate)) {
            latestArticle = article;
          }
        }
      }

      // Fetch Block Deals articles
      final blockDealsArticles = await _apiService.fetchArticlesByBlockDeals();

      if (blockDealsArticles.isNotEmpty) {
        final blockDealsArticle = blockDealsArticles.first;

        // ignore: unnecessary_null_comparison
        if (latestBlockDealsArticle == null ||
            blockDealsArticle.postDate
                .isAfter(latestBlockDealsArticle.postDate)) {
          latestBlockDealsArticle = blockDealsArticle;
        }
      }

      if (latestArticle != null) {
        if (_lastFetchedPostTime == null ||
            latestArticle.postDate.isAfter(_lastFetchedPostTime!)) {
          _lastFetchedPostTime = latestArticle.postDate;

          // Send instant notification
          await sendNotification(
            latestArticle.title,
            '${latestArticle.title}',
            latestArticle.id,
            latestArticle.imageUrl,
            'General', // Use a general channel ID
          );
        }
      }

      if (latestBlockDealsArticle != null) {
        if (_lastFetchedPostTime == null ||
            latestBlockDealsArticle.postDate.isAfter(_lastFetchedPostTime!)) {
          _lastFetchedPostTime = latestBlockDealsArticle.postDate;

          // Send instant notification
          await sendNotification(
            latestBlockDealsArticle.title,
            '${latestBlockDealsArticle.title}',
            latestBlockDealsArticle.id,
            latestBlockDealsArticle.imageUrl,
            'BlockDeals', // Use the Block Deals channel ID
          );
        }
      } else {
        print('No new articles found.');
      }
    } catch (e) {
      print('Error checking for new posts: $e');
    }
  }

  // Poll the server for new articles at a specified interval
  void startPollingForNewPosts(Duration pollingInterval) {
    _articlePollingTimer?.cancel();

    _articlePollingTimer = Timer.periodic(pollingInterval, (timer) async {
      await checkForNewArticlesAndSendNotification();
    });
  }

  // Stop the polling process
  void stopPollingForNewPosts() {
    _articlePollingTimer?.cancel();
  }

  // Manually trigger real-time notification for newly fetched posts
  Future<void> fetchArticlesAndSendNotification() async {
    await checkForNewArticlesAndSendNotification();
  }

  // Send a general notification every 30 minutes
  void startGeneralNotificationTimer() {
    _generalNotificationTimer?.cancel();

    _generalNotificationTimer = Timer.periodic(
      const Duration(minutes: 30),
      (timer) async {
        await sendGeneralNotification();
      },
    );
  }

  // Stop the general notification timer
  void stopGeneralNotificationTimer() {
    _generalNotificationTimer?.cancel();
  }

  // Send a general notification
  Future<void> sendGeneralNotification() async {
    await sendNotification(
      'General Notification',
      'This is a general notification.',
      'general_notification',
      null,
      'General', // Use a general channel ID
    );
  }

  checkForNewBlockDealsAndSendNotification() {}
}
