import 'package:bigbreakingwire/screens/block_deal_screen.dart';
import 'package:bigbreakingwire/screens/live_news_screen.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../services/api_service.dart';
import '../models/article_model.dart';
import '../widgets/custom_button.dart';
import '../widgets/interstitial_ad_widget.dart';

// Import widgets and use alias to avoid conflicts
import '../widgets/live_ticker_widget.dart' as liveTicker;
import '../widgets/article_slider_widget.dart' as articleSlider;
import '../widgets/article_list_widget.dart';
import '../widgets/drawer_menu.dart'; // Import Drawer widget
import '../widgets/navbar.dart'; // Import Custom Bottom Navigation Bar
import '../utils/design_tokens.dart'; // Import design tokens for consistent styling

class HomeScreen extends StatefulWidget {
  final Future<void> Function(bool) toggleThemeMode;

  const HomeScreen({super.key, required this.toggleThemeMode});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _apiService = ApiService();
  final RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  List<Article> _articles = [];
  int _currentPage = 1;
  bool _isLoading = false;
  bool _hasMore = true;
  final InterstitialAdWidget _interstitialAdHelper = InterstitialAdWidget();

  @override
  void initState() {
    super.initState();
    _loadArticles();
    _interstitialAdHelper.loadAd();
  }

  Future<void> _loadArticles({bool refresh = false}) async {
    if (refresh) {
      _currentPage = 1;
      _articles.clear();
      _hasMore = true;
    }

    if (!_isLoading && _hasMore) {
      setState(() {
        _isLoading = true;
      });

      try {
        final articles = await _apiService
            .fetchArticlesByCategory('BigBreakingNow', 15, page: _currentPage);

        setState(() {
          _articles.addAll(articles);
          _currentPage++;
          if (articles.length < 10) {
            _hasMore = false;
          }
          _isLoading = false;
        });

        if (refresh) {
          _refreshController.refreshCompleted();
        }
      } catch (e) {
        setState(() {
          _isLoading = false;
        });
        if (refresh) {
          _refreshController.refreshFailed();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'BigBreakingWire',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
        ),
        backgroundColor: primaryRedColor,
        iconTheme: const IconThemeData(
            color: Colors.white), // Drawer icon color set to white
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: () {
              // Navigate to the search screen (you can implement this)
            },
          ),
        ],
      ),
      drawer: DrawerMenu(
        toggleThemeMode: widget.toggleThemeMode,
        isDarkMode: Theme.of(context).brightness == Brightness.dark,
      ),
      body: SmartRefresher(
        controller: _refreshController,
        enablePullDown: true,
        enablePullUp: true,
        onRefresh: () => _loadArticles(refresh: true),
        onLoading: _loadArticles,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Column(
                children: [
                  if (_articles.isNotEmpty)
                    liveTicker.LiveTickerWidget(articles: _articles),
                  articleSlider.ArticleSliderWidget(articles: _articles),
                  const SizedBox(height: 10),
                  ArticleListWidget(
                    articles: _articles,
                    interstitialAdHelper: _interstitialAdHelper,
                  ),
                  if (_hasMore)
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: CustomButton(
                        text: 'Load More',
                        isLoading: _isLoading,
                        width: 150,
                        height: 50,
                        onPressed: _loadArticles,
                      ),
                    ),
                  if (_isLoading)
                    const Padding(
                      padding: EdgeInsets.all(10),
                      child: CircularProgressIndicator(),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: 0,
        onNavItemTapped: (index) {
          if (index != 0) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => _getScreenForIndex(index),
              ),
            );
          } else {
            setState(() {
              _loadArticles(refresh: true);
            });
          }
        },
      ),
    );
  }

  Widget _getScreenForIndex(int index) {
    switch (index) {
      case 1:
        return BlockDealScreen(toggleThemeMode: widget.toggleThemeMode);
      case 2:
        return LiveNewsScreen(toggleThemeMode: widget.toggleThemeMode);
      default:
        return HomeScreen(toggleThemeMode: widget.toggleThemeMode);
    }
  }
}
