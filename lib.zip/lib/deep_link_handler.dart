import 'package:flutter/material.dart';
import 'package:bigbreakingwire/services/api_service.dart';
import 'package:bigbreakingwire/services/link_service.dart';
import 'package:bigbreakingwire/models/article_model.dart';

class DeepLinkHandler {
  final BuildContext context;
  final ApiService _apiService = ApiService();

  DeepLinkHandler(this.context);

  void handleDeepLink(String path) {
    if (path.startsWith('https://app.bigbreakingwire.in/articles/')) {
      String id = LinkService.parseArticleId(path);
      print("Extracted article ID: $id");

      _fetchAndNavigateToArticleScreen(id);
    } else if (path.startsWith('https://app.bigbreakingwire.in/block-deals/')) {
      String id = LinkService.parseBlockDealId(path);
      print("Extracted Block Deal ID: $id");

      _fetchAndNavigateToBlockDealScreen(id);
    } else {
      print("Invalid deep link path: $path");
    }
  }

  Future<void> _fetchAndNavigateToArticleScreen(String id) async {
    try {
      Article? article = await _apiService.fetchArticleById(id);
      if (article != null) {
        _navigateToArticleScreen(article);
      } else {
        print("Article not found.");
        // Optionally show an error message to the user
        _showErrorDialog("Article not found");
      }
    } catch (error) {
      print("Error fetching article: $error");
      // Optionally show an error message to the user
      _showErrorDialog("Error loading article");
    }
  }

  Future<void> _fetchAndNavigateToBlockDealScreen(String id) async {
    try {
      Article? article = await _apiService.fetchArticleById(
          id); // Assuming Block Deal uses the same Article model
      if (article != null) {
        _navigateToBlockDealScreen(article);
      } else {
        print("Block Deal not found.");
        // Optionally show an error message to the user
        _showErrorDialog("Block Deal not found");
      }
    } catch (error) {
      print("Error fetching Block Deal: $error");
      // Optionally show an error message to the user
      _showErrorDialog("Error loading Block Deal");
    }
  }

  void _navigateToArticleScreen(Article article) {
    Navigator.pushNamed(context, '/article', arguments: article);
  }

  void _navigateToBlockDealScreen(Article article) {
    Navigator.pushNamed(context, '/block-deal', arguments: article);
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }
}
